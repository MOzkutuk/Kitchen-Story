export interface Category {
    _id: string;
    name: string;
    __v: number;
  }