# Ecommerce-rest-api
An E-commerce REST API created using Node.js, Express.js and MongoDB.
The API uses promises extensively to query the MongoDB database.

# Setup
After cloning, use "npm install" and serve the app using "node server".
